import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ─── AppProvider ───────────────────────────────────────────────────
class AppProvider extends ChangeNotifier {
  bool _isDarkMode = false;
  bool _onboardingDone = false;
  bool _isLoading = false;
  String _selectedLanguage = 'English';
  bool _hasInternet = true;

  bool get isDarkMode => _isDarkMode;
  bool get onboardingDone => _onboardingDone;
  bool get isLoading => _isLoading;
  String get selectedLanguage => _selectedLanguage;
  bool get hasInternet => _hasInternet;

  AppProvider() {
    _loadPrefs();
  }

  Future<void> _loadPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    _isDarkMode = prefs.getBool('darkMode') ?? false;
    _onboardingDone = prefs.getBool('onboardingDone') ?? false;
    _selectedLanguage = prefs.getString('language') ?? 'English';
    notifyListeners();
  }

  Future<void> toggleDarkMode() async {
    _isDarkMode = !_isDarkMode;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('darkMode', _isDarkMode);
    notifyListeners();
  }

  Future<void> completeOnboarding() async {
    _onboardingDone = true;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('onboardingDone', true);
    notifyListeners();
  }

  Future<void> setLanguage(String lang) async {
    _selectedLanguage = lang;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('language', lang);
    notifyListeners();
  }

  void setLoading(bool val) {
    _isLoading = val;
    notifyListeners();
  }

  void setInternet(bool val) {
    _hasInternet = val;
    notifyListeners();
  }
}

// ─── UserProvider ──────────────────────────────────────────────────
class UserProvider extends ChangeNotifier {
  UserModel? _currentUser;
  bool _isLoggedIn = false;
  List<UserModel> _allUsers = [];

  UserModel? get currentUser => _currentUser;
  bool get isLoggedIn => _isLoggedIn;
  List<UserModel> get allUsers => _allUsers;

  UserProvider() {
    _initDemoUsers();
  }

  void _initDemoUsers() {
    _allUsers = [
      UserModel(
        id: '1',
        name: 'Admin User',
        email: 'admin@demo.com',
        mobile: '9876543210',
        role: UserRole.admin,
        isActive: true,
        createdAt: DateTime.now().subtract(const Duration(days: 30)),
      ),
      UserModel(
        id: '2',
        name: 'John Doe',
        email: 'john@demo.com',
        mobile: '9876543211',
        role: UserRole.user,
        isActive: true,
        createdAt: DateTime.now().subtract(const Duration(days: 15)),
      ),
      UserModel(
        id: '3',
        name: 'Partner Shop',
        email: 'partner@demo.com',
        mobile: '9876543212',
        role: UserRole.partner,
        isActive: true,
        createdAt: DateTime.now().subtract(const Duration(days: 7)),
      ),
    ];
  }

  Future<bool> login(String email, String password) async {
    await Future.delayed(const Duration(seconds: 1)); // simulate API
    final user = _allUsers.firstWhere(
      (u) => u.email == email,
      orElse: () => UserModel.empty(),
    );
    if (user.id.isEmpty) return false;
    if (!user.isActive) return false;
    _currentUser = user;
    _isLoggedIn = true;
    notifyListeners();
    return true;
  }

  Future<bool> register({
    required String name,
    required String email,
    required String mobile,
    required String password,
  }) async {
    await Future.delayed(const Duration(seconds: 1));
    // Check duplicate mobile
    final exists = _allUsers.any((u) => u.mobile == mobile);
    if (exists) return false;

    final newUser = UserModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: name,
      email: email,
      mobile: mobile,
      role: UserRole.user,
      isActive: true,
      createdAt: DateTime.now(),
    );
    _allUsers.add(newUser);
    _currentUser = newUser;
    _isLoggedIn = true;
    notifyListeners();
    return true;
  }

  void logout() {
    _currentUser = null;
    _isLoggedIn = false;
    notifyListeners();
  }

  Future<void> updateProfile({required String name, String? bio}) async {
    if (_currentUser == null) return;
    _currentUser = _currentUser!.copyWith(name: name, bio: bio);
    notifyListeners();
  }

  void toggleUserBlock(String userId) {
    final idx = _allUsers.indexWhere((u) => u.id == userId);
    if (idx != -1) {
      _allUsers[idx] = _allUsers[idx].copyWith(
        isActive: !_allUsers[idx].isActive,
      );
      notifyListeners();
    }
  }

  void deleteAccount() {
    if (_currentUser == null) return;
    _allUsers.removeWhere((u) => u.id == _currentUser!.id);
    _currentUser = null;
    _isLoggedIn = false;
    notifyListeners();
  }
}

// ─── NotificationProvider ──────────────────────────────────────────
class NotificationProvider extends ChangeNotifier {
  final List<AppNotification> _notifications = [];

  List<AppNotification> get notifications => _notifications;
  int get unreadCount => _notifications.where((n) => !n.isRead).length;

  void addNotification(String title, String body, NotifType type) {
    _notifications.insert(
      0,
      AppNotification(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        title: title,
        body: body,
        type: type,
        createdAt: DateTime.now(),
      ),
    );
    notifyListeners();
  }

  void markRead(String id) {
    final idx = _notifications.indexWhere((n) => n.id == id);
    if (idx != -1) {
      _notifications[idx] = _notifications[idx].copyWith(isRead: true);
      notifyListeners();
    }
  }

  void markAllRead() {
    for (int i = 0; i < _notifications.length; i++) {
      _notifications[i] = _notifications[i].copyWith(isRead: true);
    }
    notifyListeners();
  }
}

// ─── WalletProvider ────────────────────────────────────────────────
class WalletProvider extends ChangeNotifier {
  double _balance = 1000.0;
  final List<Transaction> _transactions = [];

  double get balance => _balance;
  List<Transaction> get transactions => _transactions;

  WalletProvider() {
    _addDemoTransactions();
  }

  void _addDemoTransactions() {
    _transactions.addAll([
      Transaction(
        id: '1',
        title: 'Welcome Bonus',
        amount: 1000.0,
        type: TransactionType.credit,
        status: TransactionStatus.completed,
        createdAt: DateTime.now().subtract(const Duration(days: 5)),
      ),
    ]);
  }

  bool addMoney(double amount, {String? promoCode}) {
    double bonus = 0;
    if (promoCode == 'SAVE10') bonus = amount * 0.1;
    _balance += amount + bonus;
    _transactions.insert(
      0,
      Transaction(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        title: 'Added to Wallet${bonus > 0 ? ' + Promo Bonus' : ''}',
        amount: amount + bonus,
        type: TransactionType.credit,
        status: TransactionStatus.completed,
        createdAt: DateTime.now(),
      ),
    );
    notifyListeners();
    return true;
  }

  bool deductMoney(double amount, String title) {
    if (_balance < amount) return false; // balance can't go negative
    _balance -= amount;
    _transactions.insert(
      0,
      Transaction(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        title: title,
        amount: amount,
        type: TransactionType.debit,
        status: TransactionStatus.completed,
        createdAt: DateTime.now(),
      ),
    );
    notifyListeners();
    return true;
  }

  void refund(String transactionId) {
    final tx = _transactions.firstWhere((t) => t.id == transactionId);
    _balance += tx.amount;
    _transactions.insert(
      0,
      Transaction(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        title: 'Refund: ${tx.title}',
        amount: tx.amount,
        type: TransactionType.credit,
        status: TransactionStatus.completed,
        createdAt: DateTime.now(),
      ),
    );
    notifyListeners();
  }
}

// ─── ChatProvider ──────────────────────────────────────────────────
class ChatProvider extends ChangeNotifier {
  final Map<String, List<ChatMessage>> _chats = {};
  final List<String> _blockedUsers = [];

  List<ChatMessage> getChat(String userId) => _chats[userId] ?? [];
  bool isBlocked(String userId) => _blockedUsers.contains(userId);

  void sendMessage(String toUserId, String message, String fromUserId) {
    if (isBlocked(toUserId)) return;
    _chats.putIfAbsent(toUserId, () => []);
    _chats[toUserId]!.add(
      ChatMessage(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        fromUserId: fromUserId,
        toUserId: toUserId,
        message: message,
        status: MessageStatus.sent,
        createdAt: DateTime.now(),
      ),
    );
    notifyListeners();
    // Simulate delivered after 1 sec
    Future.delayed(const Duration(seconds: 1), () {
      final msgs = _chats[toUserId]!;
      if (msgs.isNotEmpty) {
        msgs.last = msgs.last.copyWith(status: MessageStatus.delivered);
        notifyListeners();
      }
    });
  }

  void blockUser(String userId) {
    if (!_blockedUsers.contains(userId)) {
      _blockedUsers.add(userId);
      notifyListeners();
    }
  }

  void unblockUser(String userId) {
    _blockedUsers.remove(userId);
    notifyListeners();
  }
}

// ─── Models ────────────────────────────────────────────────────────
enum UserRole { user, admin, partner }

enum NotifType { payment, system, chat, offer }

enum TransactionType { credit, debit }

enum TransactionStatus { pending, completed, failed }

enum MessageStatus { sent, delivered, read }

enum ItemStatus { pending, approved, completed, cancelled }

class UserModel {
  final String id;
  final String name;
  final String email;
  final String mobile;
  final UserRole role;
  final bool isActive;
  final DateTime createdAt;
  final String? bio;
  final String? avatar;

  UserModel({
    required this.id,
    required this.name,
    required this.email,
    required this.mobile,
    required this.role,
    required this.isActive,
    required this.createdAt,
    this.bio,
    this.avatar,
  });

  factory UserModel.empty() => UserModel(
        id: '',
        name: '',
        email: '',
        mobile: '',
        role: UserRole.user,
        isActive: false,
        createdAt: DateTime.now(),
      );

  UserModel copyWith({
    String? name,
    String? bio,
    bool? isActive,
    String? avatar,
  }) {
    return UserModel(
      id: id,
      name: name ?? this.name,
      email: email,
      mobile: mobile,
      role: role,
      isActive: isActive ?? this.isActive,
      createdAt: createdAt,
      bio: bio ?? this.bio,
      avatar: avatar ?? this.avatar,
    );
  }

  String get roleLabel {
    switch (role) {
      case UserRole.admin:
        return 'Admin';
      case UserRole.partner:
        return 'Partner';
      default:
        return 'User';
    }
  }
}

class AppNotification {
  final String id;
  final String title;
  final String body;
  final NotifType type;
  final bool isRead;
  final DateTime createdAt;

  AppNotification({
    required this.id,
    required this.title,
    required this.body,
    required this.type,
    this.isRead = false,
    required this.createdAt,
  });

  AppNotification copyWith({bool? isRead}) => AppNotification(
        id: id,
        title: title,
        body: body,
        type: type,
        isRead: isRead ?? this.isRead,
        createdAt: createdAt,
      );

  IconData get icon {
    switch (type) {
      case NotifType.payment:
        return Icons.payment;
      case NotifType.chat:
        return Icons.chat;
      case NotifType.offer:
        return Icons.local_offer;
      default:
        return Icons.notifications;
    }
  }
}

class Transaction {
  final String id;
  final String title;
  final double amount;
  final TransactionType type;
  final TransactionStatus status;
  final DateTime createdAt;

  Transaction({
    required this.id,
    required this.title,
    required this.amount,
    required this.type,
    required this.status,
    required this.createdAt,
  });
}

class ChatMessage {
  final String id;
  final String fromUserId;
  final String toUserId;
  final String message;
  final MessageStatus status;
  final DateTime createdAt;

  ChatMessage({
    required this.id,
    required this.fromUserId,
    required this.toUserId,
    required this.message,
    required this.status,
    required this.createdAt,
  });

  ChatMessage copyWith({MessageStatus? status}) => ChatMessage(
        id: id,
        fromUserId: fromUserId,
        toUserId: toUserId,
        message: message,
        status: status ?? this.status,
        createdAt: createdAt,
      );
}

class ProductItem {
  final String id;
  final String title;
  final String description;
  final double price;
  final double rating;
  ItemStatus status;
  final DateTime createdAt;

  ProductItem({
    required this.id,
    required this.title,
    required this.description,
    required this.price,
    required this.rating,
    required this.status,
    required this.createdAt,
  });
}
