import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../providers/app_provider.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final notifProv = context.watch<NotificationProvider>();
    final notifications = notifProv.notifications;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
        actions: [
          if (notifProv.unreadCount > 0)
            TextButton(
              onPressed: notifProv.markAllRead,
              child: const Text('Mark All Read'),
            ),
          IconButton(
            icon: const Icon(Icons.add_alert),
            tooltip: 'Add Test Notification',
            onPressed: () {
              notifProv.addNotification(
                'Test Notification',
                'This is a test push notification',
                NotifType.system,
              );
            },
          ),
        ],
      ),
      body: notifications.isEmpty
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.notifications_none, size: 64, color: Colors.grey),
                  SizedBox(height: 16),
                  Text('No notifications yet', style: TextStyle(color: Colors.grey)),
                ],
              ),
            )
          : ListView.builder(
              itemCount: notifications.length,
              itemBuilder: (_, i) {
                final n = notifications[i];
                return Dismissible(
                  key: Key(n.id),
                  direction: DismissDirection.endToStart,
                  background: Container(
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.only(right: 16),
                    color: Colors.red,
                    child: const Icon(Icons.delete, color: Colors.white),
                  ),
                  onDismissed: (_) => notifProv.markRead(n.id),
                  child: ListTile(
                    tileColor: n.isRead ? null : const Color(0xFF6C63FF).withOpacity(0.05),
                    leading: CircleAvatar(
                      backgroundColor: _notifColor(n.type).withOpacity(0.2),
                      child: Icon(n.icon, color: _notifColor(n.type)),
                    ),
                    title: Text(
                      n.title,
                      style: TextStyle(
                        fontWeight: n.isRead ? FontWeight.normal : FontWeight.bold,
                      ),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(n.body),
                        Text(
                          DateFormat('dd MMM, hh:mm a').format(n.createdAt),
                          style: const TextStyle(fontSize: 11, color: Colors.grey),
                        ),
                      ],
                    ),
                    trailing: n.isRead
                        ? null
                        : Container(
                            width: 8,
                            height: 8,
                            decoration: const BoxDecoration(
                              color: Color(0xFF6C63FF),
                              shape: BoxShape.circle,
                            ),
                          ),
                    onTap: () => notifProv.markRead(n.id),
                  ),
                );
              },
            ),
    );
  }

  Color _notifColor(NotifType type) {
    switch (type) {
      case NotifType.payment:
        return Colors.green;
      case NotifType.chat:
        return Colors.blue;
      case NotifType.offer:
        return Colors.orange;
      default:
        return Colors.purple;
    }
  }
}
