import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_provider.dart';

// ─── Security Screen ──────────────────────────────────────────────
class SecurityScreen extends StatefulWidget {
  const SecurityScreen({super.key});

  @override
  State<SecurityScreen> createState() => _SecurityScreenState();
}

class _SecurityScreenState extends State<SecurityScreen> {
  bool _twoFactor = false;
  bool _sessionNotif = true;
  bool _biometric = false;
  int _failedAttempts = 0;
  bool _rateLimited = false;
  final _loginInputCtrl = TextEditingController();
  String? _validationError;

  void _simulateApiCall() {
    final input = _loginInputCtrl.text;
    setState(() => _validationError = null);

    // Input validation
    if (input.isEmpty) {
      setState(() => _validationError = '❌ Input cannot be empty');
      return;
    }
    if (input.contains('<script>') || input.contains('DROP TABLE')) {
      setState(() => _validationError = '❌ Malicious input detected & blocked');
      return;
    }

    // Rate limiting simulation
    if (_rateLimited) {
      setState(() => _validationError = '⚠️ Too many requests. Rate limited. Try after 30s');
      return;
    }

    _failedAttempts++;
    if (_failedAttempts >= 3) {
      setState(() => _rateLimited = true);
      Future.delayed(const Duration(seconds: 5), () {
        if (mounted) setState(() {
          _rateLimited = false;
          _failedAttempts = 0;
        });
      });
    }

    setState(() => _validationError = '❌ Attempt ${_failedAttempts}/3. Rate limit applies after 3 fails');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Security & Validation')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _SectionTitle('Security Settings'),
            Card(
              child: Column(
                children: [
                  SwitchListTile(
                    title: const Text('Two-Factor Authentication'),
                    subtitle: const Text('Add extra layer of security'),
                    value: _twoFactor,
                    onChanged: (v) => setState(() => _twoFactor = v),
                  ),
                  SwitchListTile(
                    title: const Text('Login Notifications'),
                    subtitle: const Text('Alert on new device login'),
                    value: _sessionNotif,
                    onChanged: (v) => setState(() => _sessionNotif = v),
                  ),
                  SwitchListTile(
                    title: const Text('Biometric Login'),
                    subtitle: const Text('Use fingerprint / face ID'),
                    value: _biometric,
                    onChanged: (v) => setState(() => _biometric = v),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            _SectionTitle('Input Validation Demo'),
            const Text(
              'Try: normal text, <script>alert(1)</script>, or DROP TABLE',
              style: TextStyle(color: Colors.grey, fontSize: 12),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _loginInputCtrl,
              decoration: const InputDecoration(
                labelText: 'Test Input',
                border: OutlineInputBorder(),
                hintText: 'Type something...',
              ),
            ),
            const SizedBox(height: 8),
            if (_validationError != null)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: _validationError!.contains('❌')
                      ? Colors.red.shade50
                      : Colors.orange.shade50,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: _validationError!.contains('❌')
                        ? Colors.red.shade200
                        : Colors.orange.shade200,
                  ),
                ),
                child: Text(_validationError!),
              ),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: _simulateApiCall,
              style: ElevatedButton.styleFrom(
                backgroundColor: _rateLimited ? Colors.grey : const Color(0xFF6C63FF),
                foregroundColor: Colors.white,
              ),
              child: Text(_rateLimited ? '⏳ Rate Limited...' : 'Submit (Demo)'),
            ),
            const SizedBox(height: 24),
            _SectionTitle('Session Management'),
            Card(
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(Icons.phone_android, color: Colors.green),
                    title: const Text('This Device'),
                    subtitle: const Text('Current session - Active now'),
                    trailing: const Chip(
                      label: Text('Active'),
                      backgroundColor: Colors.green,
                      labelStyle: TextStyle(color: Colors.white),
                    ),
                  ),
                  ListTile(
                    leading: const Icon(Icons.computer, color: Colors.orange),
                    title: const Text('Chrome - Windows'),
                    subtitle: const Text('Last active: 2 days ago'),
                    trailing: TextButton(
                      onPressed: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Session terminated')),
                        );
                      },
                      child: const Text('Logout', style: TextStyle(color: Colors.red)),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            _SectionTitle('Data Encryption'),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _InfoRow('Encryption', 'AES-256 end-to-end'),
                    _InfoRow('API Auth', 'Bearer Token (JWT)'),
                    _InfoRow('Password', 'bcrypt hashed'),
                    _InfoRow('Data at rest', 'Encrypted SQLite'),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Analytics Screen ─────────────────────────────────────────────
class AnalyticsScreen extends StatelessWidget {
  const AnalyticsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final wallet = context.watch<WalletProvider>();
    final users = context.watch<UserProvider>().allUsers;
    final notifs = context.watch<NotificationProvider>().notifications;

    return Scaffold(
      appBar: AppBar(title: const Text('Analytics & Logs')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _SectionTitle('Key Metrics'),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.5,
              children: [
                _MetricCard('Total Users', users.length.toString(), Icons.people, Colors.blue),
                _MetricCard('Active Users', users.where((u) => u.isActive).length.toString(), Icons.person_outline, Colors.green),
                _MetricCard('Wallet Balance', '₹${wallet.balance.toStringAsFixed(0)}', Icons.account_balance_wallet, Colors.purple),
                _MetricCard('Transactions', wallet.transactions.length.toString(), Icons.receipt, Colors.orange),
              ],
            ),
            const SizedBox(height: 24),
            _SectionTitle('Feature Usage'),
            Card(
              child: Column(
                children: [
                  _UsageBar('Products', 0.8, Colors.blue),
                  _UsageBar('Wallet', 0.65, Colors.green),
                  _UsageBar('Chat', 0.45, Colors.orange),
                  _UsageBar('Notifications', 0.9, Colors.purple),
                ],
              ),
            ),
            const SizedBox(height: 24),
            _SectionTitle('Recent Activity Logs'),
            ...notifs.take(5).map((n) => ListTile(
                  leading: const Icon(Icons.circle, size: 10, color: Colors.green),
                  title: Text(n.title, style: const TextStyle(fontSize: 14)),
                  subtitle: Text(n.body, style: const TextStyle(fontSize: 12)),
                  dense: true,
                )),
            if (notifs.isEmpty)
              const Center(
                child: Text('No activity yet', style: TextStyle(color: Colors.grey)),
              ),
            const SizedBox(height: 24),
            _SectionTitle('Crash Logs'),
            const Card(
              child: ListTile(
                leading: Icon(Icons.check_circle, color: Colors.green),
                title: Text('No crashes in last 7 days'),
                subtitle: Text('App stability: 99.9%'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Shared Widgets ───────────────────────────────────────────────
class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Text(text,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  const _InfoRow(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Text(label, style: const TextStyle(color: Colors.grey)),
          const Spacer(),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

class _MetricCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final Color color;

  const _MetricCard(this.title, this.value, this.icon, this.color);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: color),
          const SizedBox(height: 8),
          Text(value,
              style: TextStyle(
                  fontSize: 22, fontWeight: FontWeight.bold, color: color)),
          Text(title, style: const TextStyle(fontSize: 12, color: Colors.grey)),
        ],
      ),
    );
  }
}

class _UsageBar extends StatelessWidget {
  final String label;
  final double value;
  final Color color;

  const _UsageBar(this.label, this.value, this.color);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          SizedBox(width: 120, child: Text(label)),
          Expanded(
            child: LinearProgressIndicator(
              value: value,
              color: color,
              backgroundColor: color.withOpacity(0.1),
              minHeight: 8,
              borderRadius: BorderRadius.circular(4),
            ),
          ),
          const SizedBox(width: 8),
          Text('${(value * 100).toInt()}%'),
        ],
      ),
    );
  }
}
