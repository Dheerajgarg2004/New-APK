import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_provider.dart';
import 'admin/admin_panel_screen.dart';
import 'chat/chat_list_screen.dart';
import 'security_screen.dart';
import 'analytics_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = context.watch<UserProvider>().currentUser;
    final wallet = context.watch<WalletProvider>();
    final app = context.watch<AppProvider>();

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Hello, ${user?.name.split(' ').first ?? 'User'}! 👋',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text(user?.roleLabel ?? 'User',
                style: const TextStyle(fontSize: 12, color: Colors.grey)),
          ],
        ),
        actions: [
          IconButton(
            icon: Icon(app.isDarkMode ? Icons.light_mode : Icons.dark_mode),
            onPressed: () => app.toggleDarkMode(),
          ),
          IconButton(
            icon: const Icon(Icons.wifi_off),
            tooltip: 'Simulate No Internet',
            onPressed: () => app.setInternet(!app.hasInternet),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Wallet Balance Card
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF6C63FF), Color(0xFF3D35B0)],
                ),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Wallet Balance',
                      style: TextStyle(color: Colors.white70)),
                  const SizedBox(height: 8),
                  Text(
                    '₹${wallet.balance.toStringAsFixed(2)}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            const Text('Quick Access',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.4,
              children: [
                if (user?.role == UserRole.admin)
                  _QuickCard(
                    icon: Icons.admin_panel_settings,
                    label: 'Admin Panel',
                    color: Colors.red,
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const AdminPanelScreen())),
                  ),
                _QuickCard(
                  icon: Icons.chat_bubble_outline,
                  label: 'Messages',
                  color: Colors.blue,
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const ChatListScreen())),
                ),
                _QuickCard(
                  icon: Icons.security,
                  label: 'Security',
                  color: Colors.green,
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const SecurityScreen())),
                ),
                _QuickCard(
                  icon: Icons.analytics,
                  label: 'Analytics',
                  color: Colors.orange,
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const AnalyticsScreen())),
                ),
              ],
            ),
            const SizedBox(height: 24),
            _ModuleStatusList(),
          ],
        ),
      ),
    );
  }
}

class _QuickCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _QuickCard({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 32),
            const SizedBox(height: 8),
            Text(label,
                style: TextStyle(color: color, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}

class _ModuleStatusList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final modules = [
      ('✅ User Management', 'Login, Register, OTP, Profile'),
      ('✅ Onboarding', 'Intro screens, Language, Skip logic'),
      ('✅ Core Features', 'Products CRUD, Filter, Status flow'),
      ('✅ Payment & Wallet', 'Balance, Transactions, Promo'),
      ('✅ Notifications', 'In-app, Read/Unread, Types'),
      ('✅ Admin Panel', 'User management, Approvals'),
      ('✅ Chat', '1-to-1, Block, Message status'),
      ('✅ Security', 'Session, Validation, Rate limit demo'),
      ('✅ Error Handling', 'No internet, Empty states'),
      ('✅ Analytics', 'User activity, Feature tracking'),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('All 10 Modules',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        ...modules.map((m) => ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(m.$1, style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text(m.$2),
              dense: true,
            )),
      ],
    );
  }
}
