import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../providers/app_provider.dart';

class AdminPanelScreen extends StatefulWidget {
  const AdminPanelScreen({super.key});

  @override
  State<AdminPanelScreen> createState() => _AdminPanelScreenState();
}

class _AdminPanelScreenState extends State<AdminPanelScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tab;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Panel'),
        backgroundColor: Colors.red.shade700,
        foregroundColor: Colors.white,
        bottom: TabBar(
          controller: _tab,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white60,
          indicatorColor: Colors.white,
          tabs: const [
            Tab(text: 'Users', icon: Icon(Icons.people)),
            Tab(text: 'Content', icon: Icon(Icons.article)),
            Tab(text: 'Banners', icon: Icon(Icons.image)),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tab,
        children: [
          _UsersTab(),
          _ContentTab(),
          _BannersTab(),
        ],
      ),
    );
  }
}

class _UsersTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final users = context.watch<UserProvider>().allUsers;
    final currentUser = context.watch<UserProvider>().currentUser;

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: users.length,
      itemBuilder: (_, i) {
        final user = users[i];
        final isSelf = user.id == currentUser?.id;
        return Card(
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor:
                  user.isActive ? Colors.green.shade100 : Colors.red.shade100,
              child: Text(user.name[0],
                  style: TextStyle(
                      color: user.isActive ? Colors.green : Colors.red)),
            ),
            title: Text('${user.name} ${isSelf ? '(You)' : ''}'),
            subtitle: Text('${user.email}\n${user.roleLabel}'),
            isThreeLine: true,
            trailing: isSelf
                ? null
                : Switch(
                    value: user.isActive,
                    activeColor: Colors.green,
                    onChanged: (_) {
                      context.read<UserProvider>().toggleUserBlock(user.id);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(user.isActive
                              ? '🔴 ${user.name} blocked'
                              : '🟢 ${user.name} unblocked'),
                        ),
                      );
                    },
                  ),
          ),
        );
      },
    );
  }
}

class _ContentTab extends StatefulWidget {
  @override
  State<_ContentTab> createState() => _ContentTabState();
}

class _ContentTabState extends State<_ContentTab> {
  final _items = [
    {'title': 'New Feature Announcement', 'status': 'pending'},
    {'title': 'App Update Notes', 'status': 'approved'},
    {'title': 'Terms Update', 'status': 'pending'},
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _items.length,
      itemBuilder: (_, i) {
        final item = _items[i];
        final isPending = item['status'] == 'pending';
        return Card(
          child: ListTile(
            leading: Icon(
              isPending ? Icons.pending_actions : Icons.check_circle,
              color: isPending ? Colors.orange : Colors.green,
            ),
            title: Text(item['title']!),
            subtitle: Text('Status: ${item['status']}'.toUpperCase()),
            trailing: isPending
                ? Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.check, color: Colors.green),
                        onPressed: () => setState(
                            () => _items[i]['status'] = 'approved'),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close, color: Colors.red),
                        onPressed: () => setState(
                            () => _items[i]['status'] = 'rejected'),
                      ),
                    ],
                  )
                : null,
          ),
        );
      },
    );
  }
}

class _BannersTab extends StatefulWidget {
  @override
  State<_BannersTab> createState() => _BannersTabState();
}

class _BannersTabState extends State<_BannersTab> {
  final _banners = [
    {'title': 'Summer Sale 50% Off', 'active': true, 'color': 0xFFFF6B6B},
    {'title': 'Refer & Earn ₹200', 'active': true, 'color': 0xFF4ECDC4},
    {'title': 'New Products Added', 'active': false, 'color': 0xFF6C63FF},
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _banners.length,
      itemBuilder: (_, i) {
        final b = _banners[i];
        return Card(
          child: ListTile(
            leading: Container(
              width: 40, height: 40,
              decoration: BoxDecoration(
                color: Color(b['color'] as int),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.image, color: Colors.white),
            ),
            title: Text(b['title'] as String),
            subtitle: Text((b['active'] as bool) ? '🟢 Active' : '⚫ Inactive'),
            trailing: Switch(
              value: b['active'] as bool,
              onChanged: (v) => setState(() => _banners[i]['active'] = v),
            ),
          ),
        );
      },
    );
  }
}
