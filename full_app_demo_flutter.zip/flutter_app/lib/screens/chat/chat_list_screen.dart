import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../providers/app_provider.dart';

// ─── Chat List Screen ─────────────────────────────────────────────
class ChatListScreen extends StatelessWidget {
  const ChatListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final users = context.watch<UserProvider>().allUsers;
    final currentUser = context.watch<UserProvider>().currentUser;
    final chatProv = context.watch<ChatProvider>();

    final otherUsers = users.where((u) => u.id != currentUser?.id).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Messages')),
      body: otherUsers.isEmpty
          ? const Center(child: Text('No users to chat with'))
          : ListView.builder(
              itemCount: otherUsers.length,
              itemBuilder: (_, i) {
                final user = otherUsers[i];
                final isBlocked = chatProv.isBlocked(user.id);
                final messages = chatProv.getChat(user.id);
                final lastMsg = messages.isNotEmpty ? messages.last : null;

                return ListTile(
                  leading: Stack(
                    children: [
                      CircleAvatar(
                        backgroundColor: isBlocked
                            ? Colors.grey.shade300
                            : const Color(0xFF6C63FF).withOpacity(0.2),
                        child: Text(user.name[0],
                            style: const TextStyle(
                                color: Color(0xFF6C63FF),
                                fontWeight: FontWeight.bold)),
                      ),
                      if (isBlocked)
                        const Positioned(
                          right: 0, bottom: 0,
                          child: Icon(Icons.block, size: 14, color: Colors.red),
                        ),
                    ],
                  ),
                  title: Text(user.name),
                  subtitle: Text(
                    isBlocked
                        ? '🔴 Blocked'
                        : lastMsg?.message ?? 'Tap to chat',
                    style: TextStyle(color: isBlocked ? Colors.red : null),
                  ),
                  trailing: isBlocked
                      ? null
                      : lastMsg != null
                          ? Text(
                              DateFormat('hh:mm').format(lastMsg.createdAt),
                              style: const TextStyle(fontSize: 11),
                            )
                          : null,
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ChatScreen(otherUser: user),
                    ),
                  ),
                );
              },
            ),
    );
  }
}

// ─── Chat Screen ─────────────────────────────────────────────────
class ChatScreen extends StatefulWidget {
  final UserModel otherUser;
  const ChatScreen({super.key, required this.otherUser});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _msgCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();

  void _send() {
    final text = _msgCtrl.text.trim();
    if (text.isEmpty) return;

    final currentUser = context.read<UserProvider>().currentUser!;
    final chatProv = context.read<ChatProvider>();

    if (chatProv.isBlocked(widget.otherUser.id)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('User is blocked. Unblock to chat.'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    chatProv.sendMessage(widget.otherUser.id, text, currentUser.id);
    context.read<NotificationProvider>().addNotification(
          'Message Sent',
          'To ${widget.otherUser.name}: $text',
          NotifType.chat,
        );
    _msgCtrl.clear();

    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final currentUser = context.watch<UserProvider>().currentUser!;
    final chatProv = context.watch<ChatProvider>();
    final messages = chatProv.getChat(widget.otherUser.id);
    final isBlocked = chatProv.isBlocked(widget.otherUser.id);

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.otherUser.name),
            Text(isBlocked ? '🔴 Blocked' : '🟢 Online',
                style: const TextStyle(fontSize: 12)),
          ],
        ),
        actions: [
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'block') {
                chatProv.blockUser(widget.otherUser.id);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('${widget.otherUser.name} blocked'),
                    backgroundColor: Colors.red,
                  ),
                );
              } else if (v == 'unblock') {
                chatProv.unblockUser(widget.otherUser.id);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('${widget.otherUser.name} unblocked'),
                    backgroundColor: Colors.green,
                  ),
                );
              }
            },
            itemBuilder: (_) => [
              if (!isBlocked)
                const PopupMenuItem(value: 'block', child: Text('🔴 Block User'))
              else
                const PopupMenuItem(value: 'unblock', child: Text('🟢 Unblock User')),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          if (isBlocked)
            Container(
              color: Colors.red.shade50,
              padding: const EdgeInsets.all(8),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.block, color: Colors.red, size: 16),
                  SizedBox(width: 8),
                  Text('You have blocked this user',
                      style: TextStyle(color: Colors.red)),
                ],
              ),
            ),
          Expanded(
            child: messages.isEmpty
                ? const Center(
                    child: Text('No messages yet. Say Hi!',
                        style: TextStyle(color: Colors.grey)))
                : ListView.builder(
                    controller: _scrollCtrl,
                    padding: const EdgeInsets.all(16),
                    itemCount: messages.length,
                    itemBuilder: (_, i) {
                      final msg = messages[i];
                      final isMe = msg.fromUserId == currentUser.id;
                      return Align(
                        alignment:
                            isMe ? Alignment.centerRight : Alignment.centerLeft,
                        child: Container(
                          margin: const EdgeInsets.only(bottom: 8),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 10),
                          constraints: BoxConstraints(
                              maxWidth:
                                  MediaQuery.of(context).size.width * 0.7),
                          decoration: BoxDecoration(
                            color: isMe
                                ? const Color(0xFF6C63FF)
                                : Colors.grey.shade200,
                            borderRadius: BorderRadius.circular(16).copyWith(
                              bottomRight: isMe
                                  ? const Radius.circular(4)
                                  : null,
                              bottomLeft: !isMe
                                  ? const Radius.circular(4)
                                  : null,
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                msg.message,
                                style: TextStyle(
                                    color: isMe ? Colors.white : Colors.black87),
                              ),
                              const SizedBox(height: 4),
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    DateFormat('hh:mm a').format(msg.createdAt),
                                    style: TextStyle(
                                      fontSize: 10,
                                      color: isMe
                                          ? Colors.white60
                                          : Colors.grey,
                                    ),
                                  ),
                                  if (isMe) ...[
                                    const SizedBox(width: 4),
                                    Icon(
                                      msg.status == MessageStatus.delivered
                                          ? Icons.done_all
                                          : Icons.done,
                                      size: 12,
                                      color: Colors.white60,
                                    ),
                                  ],
                                ],
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              boxShadow: [
                BoxShadow(
                    color: Colors.black12, offset: const Offset(0, -1), blurRadius: 4)
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _msgCtrl,
                    enabled: !isBlocked,
                    decoration: InputDecoration(
                      hintText: isBlocked ? 'User is blocked' : 'Type a message...',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24)),
                      contentPadding:
                          const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    ),
                    onSubmitted: (_) => _send(),
                  ),
                ),
                const SizedBox(width: 8),
                CircleAvatar(
                  backgroundColor: isBlocked ? Colors.grey : const Color(0xFF6C63FF),
                  child: IconButton(
                    icon: const Icon(Icons.send, color: Colors.white),
                    onPressed: isBlocked ? null : _send,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
