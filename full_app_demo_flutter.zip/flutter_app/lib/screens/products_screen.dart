import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_provider.dart';

class ProductsScreen extends StatefulWidget {
  const ProductsScreen({super.key});

  @override
  State<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  final _searchCtrl = TextEditingController();
  String _search = '';
  String _sortBy = 'Latest';
  ItemStatus? _filterStatus;

  final List<ProductItem> _products = [
    ProductItem(
      id: '1',
      title: 'Premium Headphones',
      description: 'High quality wireless headphones',
      price: 2999,
      rating: 4.5,
      status: ItemStatus.approved,
      createdAt: DateTime.now().subtract(const Duration(days: 2)),
    ),
    ProductItem(
      id: '2',
      title: 'Smart Watch',
      description: 'Fitness tracker with heart rate monitor',
      price: 4999,
      rating: 4.2,
      status: ItemStatus.pending,
      createdAt: DateTime.now().subtract(const Duration(days: 1)),
    ),
    ProductItem(
      id: '3',
      title: 'Laptop Stand',
      description: 'Ergonomic aluminum laptop stand',
      price: 1499,
      rating: 4.8,
      status: ItemStatus.completed,
      createdAt: DateTime.now().subtract(const Duration(days: 5)),
    ),
    ProductItem(
      id: '4',
      title: 'Wireless Keyboard',
      description: 'Bluetooth mechanical keyboard',
      price: 3499,
      rating: 4.0,
      status: ItemStatus.cancelled,
      createdAt: DateTime.now().subtract(const Duration(days: 3)),
    ),
  ];

  List<ProductItem> get _filtered {
    var list = _products.where((p) {
      final matchSearch =
          p.title.toLowerCase().contains(_search.toLowerCase()) ||
              p.description.toLowerCase().contains(_search.toLowerCase());
      final matchStatus = _filterStatus == null || p.status == _filterStatus;
      return matchSearch && matchStatus;
    }).toList();

    switch (_sortBy) {
      case 'Price ↑':
        list.sort((a, b) => a.price.compareTo(b.price));
        break;
      case 'Price ↓':
        list.sort((a, b) => b.price.compareTo(a.price));
        break;
      case 'Rating':
        list.sort((a, b) => b.rating.compareTo(a.rating));
        break;
      default:
        list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    }
    return list;
  }

  void _showAddDialog() {
    final titleCtrl = TextEditingController();
    final priceCtrl = TextEditingController();
    final descCtrl = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Add Product'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: titleCtrl,
              decoration: const InputDecoration(labelText: 'Title', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: descCtrl,
              decoration: const InputDecoration(labelText: 'Description', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: priceCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Price (₹)', border: OutlineInputBorder()),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              if (titleCtrl.text.isEmpty) return;
              setState(() {
                _products.insert(
                  0,
                  ProductItem(
                    id: DateTime.now().millisecondsSinceEpoch.toString(),
                    title: titleCtrl.text,
                    description: descCtrl.text,
                    price: double.tryParse(priceCtrl.text) ?? 0,
                    rating: 0,
                    status: ItemStatus.pending,
                    createdAt: DateTime.now(),
                  ),
                );
              });
              context.read<NotificationProvider>().addNotification(
                    'Product Added',
                    '${titleCtrl.text} submitted for approval',
                    NotifType.system,
                  );
              Navigator.pop(context);
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }

  void _advanceStatus(ProductItem item) {
    setState(() {
      switch (item.status) {
        case ItemStatus.pending:
          item.status = ItemStatus.approved;
          break;
        case ItemStatus.approved:
          item.status = ItemStatus.completed;
          break;
        default:
          break;
      }
    });
  }

  void _deleteProduct(ProductItem item) {
    setState(() {
      _products.remove(item);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Product deleted')),
    );
  }

  Color _statusColor(ItemStatus s) {
    switch (s) {
      case ItemStatus.pending:
        return Colors.orange;
      case ItemStatus.approved:
        return Colors.blue;
      case ItemStatus.completed:
        return Colors.green;
      case ItemStatus.cancelled:
        return Colors.red;
    }
  }

  String _statusLabel(ItemStatus s) {
    switch (s) {
      case ItemStatus.pending:
        return 'Pending';
      case ItemStatus.approved:
        return 'Approved';
      case ItemStatus.completed:
        return 'Completed';
      case ItemStatus.cancelled:
        return 'Cancelled';
    }
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _filtered;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Products'),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.sort),
            onSelected: (v) => setState(() => _sortBy = v),
            itemBuilder: (_) => ['Latest', 'Price ↑', 'Price ↓', 'Rating']
                .map((s) => PopupMenuItem(value: s, child: Text(s)))
                .toList(),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddDialog,
        child: const Icon(Icons.add),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                TextField(
                  controller: _searchCtrl,
                  decoration: InputDecoration(
                    hintText: 'Search products...',
                    prefixIcon: const Icon(Icons.search),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    suffixIcon: _search.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.clear),
                            onPressed: () => setState(() {
                              _search = '';
                              _searchCtrl.clear();
                            }),
                          )
                        : null,
                  ),
                  onChanged: (v) => setState(() => _search = v),
                ),
                const SizedBox(height: 8),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      const Text('Filter: '),
                      ...[null, ItemStatus.pending, ItemStatus.approved,
                              ItemStatus.completed, ItemStatus.cancelled]
                          .map((s) => Padding(
                                padding: const EdgeInsets.only(right: 8),
                                child: FilterChip(
                                  label: Text(s == null ? 'All' : _statusLabel(s)),
                                  selected: _filterStatus == s,
                                  onSelected: (_) =>
                                      setState(() => _filterStatus = s),
                                ),
                              )),
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (filtered.isEmpty)
            const Expanded(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.inbox, size: 64, color: Colors.grey),
                    SizedBox(height: 16),
                    Text('No products found', style: TextStyle(color: Colors.grey)),
                  ],
                ),
              ),
            )
          else
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: filtered.length,
                itemBuilder: (_, i) {
                  final item = filtered[i];
                  return Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    child: ListTile(
                      contentPadding: const EdgeInsets.all(12),
                      title: Row(
                        children: [
                          Expanded(
                            child: Text(item.title,
                                style: const TextStyle(fontWeight: FontWeight.bold)),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: _statusColor(item.status).withOpacity(0.2),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              _statusLabel(item.status),
                              style: TextStyle(
                                  color: _statusColor(item.status),
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      ),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 4),
                          Text(item.description),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              Text('₹${item.price.toStringAsFixed(0)}',
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Color(0xFF6C63FF))),
                              const Spacer(),
                              if (item.rating > 0) ...[
                                const Icon(Icons.star, color: Colors.amber, size: 16),
                                Text(item.rating.toString()),
                              ],
                            ],
                          ),
                          const SizedBox(height: 8),
                          if (item.status == ItemStatus.pending ||
                              item.status == ItemStatus.approved)
                            Row(
                              children: [
                                TextButton(
                                  onPressed: () => _advanceStatus(item),
                                  child: Text(
                                    item.status == ItemStatus.pending
                                        ? 'Approve →'
                                        : 'Mark Complete →',
                                    style: const TextStyle(fontSize: 12),
                                  ),
                                ),
                                TextButton(
                                  onPressed: () => setState(
                                      () => item.status = ItemStatus.cancelled),
                                  child: const Text('Cancel',
                                      style: TextStyle(
                                          color: Colors.red, fontSize: 12)),
                                ),
                                const Spacer(),
                                IconButton(
                                  icon: const Icon(Icons.delete_outline,
                                      color: Colors.red),
                                  onPressed: () => _deleteProduct(item),
                                ),
                              ],
                            ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }
}
